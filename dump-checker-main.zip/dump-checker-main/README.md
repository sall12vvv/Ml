# Moonton Dump + Checker Email Password
## Instalasi
-  pkg update && pkg upgrade
-  pkg install python git
-  pkg install nano
-  pkg install pv
-  pkg install curl
-  pkg install wget
-  pip install requests futures
-  git clone https://github.com/aceptriana/dump-checker
-  cd dump-checker
## Moonton Dump Email + Password
- bash empass.sh
## Moonton checker
- python cek.py
- create list using nano save as in dir dump-checker
